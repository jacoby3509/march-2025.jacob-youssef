function _classPrivateFieldBase(e, t) {
  if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
  return e;
}
module.exports = _classPrivateFieldBase, module.exports.__esModule = true, module.exports["default"] = module.exports;