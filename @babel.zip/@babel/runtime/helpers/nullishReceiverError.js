function _nullishReceiverError(r) {
  throw new TypeError("Cannot set property of null or undefined.");
}
module.exports = _nullishReceiverError, module.exports.__esModule = true, module.exports["default"] = module.exports;