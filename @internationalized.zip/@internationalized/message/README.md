# @internationalized/message

This package is part of [react-spectrum](https://github.com/adobe/react-spectrum). See the repo for more details.