declare const isCore: (x: string, _nodeVersion?: any) => boolean;

export = isCore;
