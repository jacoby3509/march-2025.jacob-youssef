/// <reference types="node" />
export declare const CWD: string;
export declare const cjsRequire: NodeRequire;
export declare const EXTENSIONS: string[];
