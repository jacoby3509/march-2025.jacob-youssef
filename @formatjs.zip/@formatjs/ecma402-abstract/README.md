# ECMA402 Abstract

Implementation for various ECMAScript 402 abstract operations.

[![npm Version](https://img.shields.io/npm/v/@formatjs/ecma402-abstract.svg?style=flat-square)](https://www.npmjs.org/package/@formatjs/ecma402-abstract)

**IMPORTANT: This does not follow semver so please pin the version to the exact one that you need.**
