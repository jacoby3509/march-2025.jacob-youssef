"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FormatNumeric = FormatNumeric;
var PartitionNumberPattern_1 = require("./PartitionNumberPattern");
function FormatNumeric(internalSlots, x) {
    var parts = (0, PartitionNumberPattern_1.PartitionNumberPattern)(internalSlots, x);
    return parts.map(function (p) { return p.value; }).join('');
}
