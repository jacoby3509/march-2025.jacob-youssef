"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NEGATIVE_ZERO = exports.ZERO = exports.TEN = void 0;
var tslib_1 = require("tslib");
var decimal_js_1 = tslib_1.__importDefault(require("decimal.js"));
exports.TEN = new decimal_js_1.default(10);
exports.ZERO = new decimal_js_1.default(0);
exports.NEGATIVE_ZERO = new decimal_js_1.default(-0);
