/**
 * https://tc39.es/ecma402/#sec-canonicalizetimezonename
 * @param tz
 */
export declare function CanonicalizeTimeZoneName(tz: string, { zoneNames, uppercaseLinks, }: {
    zoneNames: readonly string[];
    uppercaseLinks: Record<string, string>;
}): string;
