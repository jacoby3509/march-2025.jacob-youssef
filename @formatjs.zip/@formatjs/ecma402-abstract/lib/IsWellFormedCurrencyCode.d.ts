/**
 * https://tc39.es/ecma402/#sec-iswellformedcurrencycode
 */
export declare function IsWellFormedCurrencyCode(currency: string): boolean;
