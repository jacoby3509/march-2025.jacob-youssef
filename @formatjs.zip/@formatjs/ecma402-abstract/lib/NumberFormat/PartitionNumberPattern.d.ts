import Decimal from 'decimal.js';
import { NumberFormatInternal, NumberFormatPart } from '../types/number';
/**
 * https://tc39.es/ecma402/#sec-partitionnumberpattern
 */
export declare function PartitionNumberPattern(internalSlots: NumberFormatInternal, _x: Decimal): NumberFormatPart[];
