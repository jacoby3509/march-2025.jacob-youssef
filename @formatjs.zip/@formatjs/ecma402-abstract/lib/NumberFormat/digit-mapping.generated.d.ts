export declare const digitMapping: Record<string, ReadonlyArray<string>>;
