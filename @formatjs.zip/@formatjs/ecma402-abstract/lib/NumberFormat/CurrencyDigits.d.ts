/**
 * https://tc39.es/ecma402/#sec-currencydigits
 */
export declare function CurrencyDigits(c: string, { currencyDigitsData }: {
    currencyDigitsData: Record<string, number>;
}): number;
