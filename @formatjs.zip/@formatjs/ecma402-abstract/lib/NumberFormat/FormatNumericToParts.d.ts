import Decimal from 'decimal.js';
import { NumberFormatInternal, NumberFormatPart } from '../types/number';
export declare function FormatNumericToParts(nf: Intl.NumberFormat, x: Decimal, implDetails: {
    getInternalSlots(nf: Intl.NumberFormat): NumberFormatInternal;
}): NumberFormatPart[];
