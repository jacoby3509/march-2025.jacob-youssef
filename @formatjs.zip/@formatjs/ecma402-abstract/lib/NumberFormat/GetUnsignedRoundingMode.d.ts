import { RoundingModeType, UnsignedRoundingModeType } from '../types/number';
export declare function GetUnsignedRoundingMode(roundingMode: RoundingModeType, isNegative: boolean): UnsignedRoundingModeType;
