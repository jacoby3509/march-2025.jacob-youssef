import Decimal from 'decimal.js';
import { UnsignedRoundingModeType } from '../types/number';
export declare function ApplyUnsignedRoundingMode(x: Decimal, r1: Decimal, r2: Decimal, unsignedRoundingMode: UnsignedRoundingModeType): Decimal;
