import Decimal from 'decimal.js';
import { NumberFormatInternal } from '../types/number';
export declare function FormatNumeric(internalSlots: NumberFormatInternal, x: Decimal): string;
