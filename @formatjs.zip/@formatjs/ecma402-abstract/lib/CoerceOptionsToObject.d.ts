/**
 * https://tc39.es/ecma402/#sec-coerceoptionstoobject
 * @param options
 * @returns
 */
export declare function CoerceOptionsToObject<T>(options?: T): T;
