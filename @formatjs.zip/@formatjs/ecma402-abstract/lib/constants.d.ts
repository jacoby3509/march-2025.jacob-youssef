import Decimal from 'decimal.js';
export declare const TEN: Decimal;
export declare const ZERO: Decimal;
export declare const NEGATIVE_ZERO: Decimal;
