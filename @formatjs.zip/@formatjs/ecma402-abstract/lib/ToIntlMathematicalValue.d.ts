import Decimal from 'decimal.js';
export declare function ToIntlMathematicalValue(input: unknown): Decimal;
