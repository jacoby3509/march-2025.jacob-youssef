declare class MissingLocaleDataError extends Error {
    type: string;
}
export declare function isMissingLocaleDataError(e: Error): e is MissingLocaleDataError;
export {};
