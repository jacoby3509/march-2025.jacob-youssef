/**
 * https://tc39.es/ecma402/#sec-getoptionsobject
 * @param options
 * @returns
 */
export declare function GetOptionsObject<T extends object>(options?: T): T;
