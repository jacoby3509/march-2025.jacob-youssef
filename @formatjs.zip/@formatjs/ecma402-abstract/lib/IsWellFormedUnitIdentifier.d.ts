/**
 * https://tc39.es/ecma402/#sec-iswellformedunitidentifier
 * @param unit
 */
export declare function IsWellFormedUnitIdentifier(unit: string): boolean;
