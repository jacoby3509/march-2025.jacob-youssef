export declare const S_UNICODE_REGEX: RegExp;
