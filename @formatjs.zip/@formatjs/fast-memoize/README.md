# @formatjs/fast-memoize

This is just a fork of `fast-memoize`.
