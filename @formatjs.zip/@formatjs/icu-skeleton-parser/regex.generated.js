"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WHITE_SPACE_REGEX = void 0;
// @generated from regex-gen.ts
exports.WHITE_SPACE_REGEX = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
