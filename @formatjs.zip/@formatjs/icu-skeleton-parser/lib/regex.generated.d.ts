export declare const WHITE_SPACE_REGEX: RegExp;
