import { Parser, ParserOptions } from './parser';
import { MessageFormatElement } from './types';
export declare function parse(message: string, opts?: ParserOptions): MessageFormatElement[];
export * from './types';
export type { ParserOptions };
export declare const _Parser: typeof Parser;
export { isStructurallySame } from './manipulator';
