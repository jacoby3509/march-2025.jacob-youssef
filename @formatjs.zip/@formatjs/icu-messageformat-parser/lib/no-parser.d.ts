export declare function parse(): void;
export * from './types';
export declare const _Parser: undefined;
export { isStructurallySame } from './manipulator';
