export declare const timeData: Record<string, string[]>;
