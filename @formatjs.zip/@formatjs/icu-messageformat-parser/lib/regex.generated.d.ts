export declare const SPACE_SEPARATOR_REGEX: RegExp;
export declare const WHITE_SPACE_REGEX: RegExp;
