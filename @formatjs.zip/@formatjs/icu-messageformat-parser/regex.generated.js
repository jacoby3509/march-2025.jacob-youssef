"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WHITE_SPACE_REGEX = exports.SPACE_SEPARATOR_REGEX = void 0;
// @generated from regex-gen.ts
exports.SPACE_SEPARATOR_REGEX = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/;
exports.WHITE_SPACE_REGEX = /[\t-\r \x85\u200E\u200F\u2028\u2029]/;
