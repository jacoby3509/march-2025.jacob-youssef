export declare function CanonicalizeUnicodeLocaleId(locale: string): string;
