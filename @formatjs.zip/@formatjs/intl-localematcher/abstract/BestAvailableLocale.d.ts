/**
 * https://tc39.es/ecma402/#sec-bestavailablelocale
 * @param availableLocales
 * @param locale
 */
export declare function BestAvailableLocale(availableLocales: readonly string[], locale: string): string | undefined;
