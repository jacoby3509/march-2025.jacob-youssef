"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CanonicalizeUnicodeLocaleId = CanonicalizeUnicodeLocaleId;
function CanonicalizeUnicodeLocaleId(locale) {
    return Intl.getCanonicalLocales(locale)[0];
}
