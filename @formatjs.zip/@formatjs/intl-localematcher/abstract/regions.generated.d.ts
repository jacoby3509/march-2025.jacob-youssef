export declare const regions: Record<string, string[]>;
