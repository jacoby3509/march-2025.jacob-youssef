export declare function CanonicalizeUValue(ukey: string, uvalue: string): string;
