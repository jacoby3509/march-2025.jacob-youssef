import { Keyword } from './types';
export declare function InsertUnicodeExtensionAndCanonicalize(locale: string, attributes: string[], keywords: Array<Keyword>): string;
