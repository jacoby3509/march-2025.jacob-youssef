/**
 * https://tc39.es/ecma402/#sec-lookupsupportedlocales
 * @param availableLocales
 * @param requestedLocales
 */
export declare function LookupSupportedLocales(availableLocales: string[], requestedLocales: string[]): string[];
