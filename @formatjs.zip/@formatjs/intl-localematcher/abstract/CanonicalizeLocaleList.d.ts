/**
 * http://ecma-international.org/ecma-402/7.0/index.html#sec-canonicalizelocalelist
 * @param locales
 */
export declare function CanonicalizeLocaleList(locales?: string | readonly string[]): string[];
