import { Keyword } from './types';
export declare function UnicodeExtensionComponents(extension: string): {
    attributes: string[];
    keywords: Array<Keyword>;
};
