/**
 * https://tc39.es/ecma402/#sec-unicodeextensionvalue
 * @param extension
 * @param key
 */
export declare function UnicodeExtensionValue(extension: string, key: string): string | undefined;
